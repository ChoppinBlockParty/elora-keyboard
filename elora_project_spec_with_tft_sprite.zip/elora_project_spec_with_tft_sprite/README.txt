Contents:
- keyboard_project_agreed_spec_v2.md — current agreed project specification
- assets/tft_idle_smiley_sprite_sheet.png — last approved TFT idle animation sprite sheet
